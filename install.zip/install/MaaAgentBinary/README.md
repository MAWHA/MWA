# MaaAgentBinary

## minitouch

from [minitouch-prebuilt](https://github.com/openatx/stf-binaries/tree/master/node_modules/minitouch-prebuilt)

## maatouch

from [MaaTouch](https://github.com/MaaAssistantArknights/MaaTouch)

## minicap

from [minicap-prebuilt](https://github.com/openatx/stf-binaries/tree/master/node_modules/minicap-prebuilt)
